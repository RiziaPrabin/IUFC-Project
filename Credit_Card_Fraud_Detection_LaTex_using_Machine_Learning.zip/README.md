## About the contents

This repository contains necessary templates to create reports and presentations for Intel-Unnati program. For presentation use the `Fake-news.tex` file. For article use the `main.tex` template.
